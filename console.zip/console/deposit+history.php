
<?php

require_once 'controllers/authController.php'; 

if (!isset($_SESSION['id'])) {
	header('Location: login.php');
	exit();
}

?>

<!DOCTYPE html>
<html lang="en" class="gr__bittradecapitals_com"><head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no, minimal-ui">
        <title>Deposit History - BIT TRADE ASSETS</title>

        <!-- Common Plugins -->
        <link href="assets/lib/bootstrap/css/bootstrap.min.css" rel="stylesheet">

		<!-- DataTimePicker -->
        <link href="assets/lib/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
		
		<!-- Clock Picker -->
		<link href="assets/lib/clockpicker/bootstrap-clockpicker.min.css" rel="stylesheet">

        <!-- Custom Css-->
        <link href="assets/scss/style.css" rel="stylesheet">

        <!-- DataTables -->
        <link href="assets/lib/datatables/jquery.dataTables.min.css" rel="stylesheet" type="text/css">
        <link href="assets/lib/datatables/responsive.bootstrap.min.css" rel="stylesheet" type="text/css">
		 <link href="assets/lib/datatables/buttons.dataTables.css" rel="stylesheet" type="text/css">
		
        <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
          <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
          <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="  pace-done" data-gr-c-s-loaded="true" cz-shortcut-listen="true"><div class="pace  pace-inactive"><div class="pace-progress" data-progress-text="100%" data-progress="99" style="transform: translate3d(100%, 0px, 0px);">
  <div class="pace-progress-inner"></div>
</div>
<div class="pace-activity"></div></div>

			<!-- ============================================================== -->
			<!-- 						Topbar Start 							-->
			<!-- ============================================================== -->
			<div class="top-bar primary-top-bar">
			<div class="container-fluid">
				<div class="row">
					<div class="col" style="background-color: #88D05F;">
						<a class="admin-logo" href="https://bittradeassets.com/">
							<h1>
								<img alt="" src="assets/img/icon.png" class="logo-icon margin-r-10">
								<img alt="" src="assets/img/logo-dark.png" class="toggle-none hidden-xs">
							</h1>
						</a>				
						<div class="left-nav-toggle">
							<a href="#" class="nav-collapse"><i class="fa fa-bars"></i></a>
						</div>
						<div class="left-nav-collapsed">
							<a href="#" class="nav-collapsed"><i class="fa fa-bars"></i></a>
						</div>
						<ul class="list-inline top-right-nav">
							<li class="dropdown avtar-dropdown">
								<a class="dropdown-toggle" data-toggle="dropdown" href="#">
									<img alt="" class="rounded-circle" src="assets/img/avtar-2.png" width="30">
									HANK								</a>
								<ul class="dropdown-menu top-dropdown">
									<li>
										<a class="dropdown-item" href="referral.php"><i class="icon-bell"></i> Activities</a>
									</li>
									<li>
										<a class="dropdown-item" href="profile.php"><i class="icon-user"></i> Profile</a>
									</li>
									<li class="dropdown-divider"></li>
									<li>
										<a class="dropdown-item" href="logout.php"><i class="icon-logout"></i> Logout</a>
									</li>
								</ul>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- ============================================================== -->
		<!--                        Topbar End                              -->
		<!-- ============================================================== -->
		
		
		

                <!-- ============================================================== -->
		<!-- 						Navigation Start 						-->
		<!-- ============================================================== -->
        <div class="main-sidebar-nav default-navigation">
            <div class="nano has-scrollbar">
                <div class="nano-content sidebar-nav" tabindex="0" style="right: -17px;">
				
					<div class="card-body border-bottom text-center nav-profile">
						<div class="notify setpos"> <span class="heartbit"></span> <span class="point"></span> </div>
                        <img alt="profile" class="margin-b-10  " src="assets/img/avtar-2.png" width="80">
                        <p class="lead margin-b-0 toggle-none">HANK</p>
                        <p class="text-muted mv-0 toggle-none">Welcome</p>						
                    </div>
					
                     <ul class="metisMenu nav flex-column" id="menu">
                        <li class="nav-heading"><span>MAIN</span></li>
						<li class="nav-item"><a class="nav-link" href="index.php"><i class="fa fa-home"></i> <span class="toggle-none">Dashboard <span class="badge badge-pill badge-danger float-right mr-2">1.0</span></span></a></li>		
						<li class="nav-heading"><span>Finances</span></li>				
                        <li class="nav-item">
                            <a class="nav-link" href="javascript: void(0);" aria-expanded="false"><i class="fa fa-google-wallet"></i> <span class="toggle-none">Transactions<span class="fa arrow"></span></span></a>
                            <ul class="nav-second-level nav flex-column sub-menu collapse" aria-expanded="false">
								<li class="nav-item"><a class="nav-link" href="deposit.php">Deposit Funds</a></li>
                                <li class="nav-item"><a class="nav-link" href="withdraw.php">Withdrawal Funds</a></li>
                            </ul>
                        </li>
                        <li class="nav-heading"><span>Account Summary</span></li>	
						 <li class="nav-item active">
                            <a class="nav-link" href="javascript: void(0);" aria-expanded="false"><i class="fa fa-database"></i> <span class="toggle-none">History<span class="fa arrow"></span></span></a>
                            <ul class="nav-second-level nav flex-column sub-menu collapse in" aria-expanded="true">
								<li class="nav-item"><a class="nav-link" href="deposit+history.php">Deposit History</a></li>
                                <li class="nav-item"><a class="nav-link" href="withdraw+history.php">Withdrawal History</a></li>
								<li class="nav-item"><a class="nav-link" href="trading+history.php">Trading History</a></li>
                            </ul>
                        </li>
                        <li class="nav-heading"><span>Referrals</span></li>
						<li class="nav-item">
                            <a class="nav-link" href="referral.php" aria-expanded="false"><i class="fa fa-link"></i> <span class="toggle-none">Referrals</span></a>
                        </li>
                        <li class="nav-heading"><span>Settings</span></li>

                        <li class="nav-item">
                            <a class="nav-link" href="profile.php" aria-expanded="false"><i class="fa fa-cogs"></i> <span class="toggle-none">Profile</span></a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="logout.php" aria-expanded="false"><i class="fa fa-lock"></i> <span class="toggle-none">Logout</span></a>
                        </li>						
                    </ul>
                </div>
            <div class="nano-pane"><div class="nano-slider" style="height: 174px; transform: translate(0px, 0px);"></div></div></div>
        </div>
        <!-- ============================================================== -->
		<!-- 						Navigation End	 						-->
		<!-- ============================================================== -->


        <!-- ============================================================== -->
		<!-- 						Content Start	 						-->
		<!-- ============================================================== -->
		<div class="row page-header">
		<div class="col-lg-6 align-self-center ">
			   <h2>History</h2>
				<ol class="breadcrumb">
					<li class="breadcrumb-item"><a href="#">Home</a></li>
					<li class="breadcrumb-item"><a href="#">History</a></li>
					<li class="breadcrumb-item active"> Deposit</li>
				</ol>
			</div>
		</div>

        <section class="main-content">
            <div class="row">             

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-default">
                            Deposit History
                        </div>
                        <form id="hist_form">
                        	<div class="card-body">
	                        	<div class="row">
									<div class="col-md-6">
										<h5><small>From</small></h5>
										<div class="form-group">
											<div class="input-group m-b">
											<span class="input-group-addon"><i class="glyphicon glyphicon-calendar fa fa-calendar"></i></span>
											<input type="date" class="form-control" id="from_calendar" name="from_calendar" value="10/24/1984" required="">
											</div>
										</div>
									</div>
									
									<div class="col-md-6">
										<h5><small>To</small></h5>
										<div class="form-group">
											<div class="input-group m-b">
											<span class="input-group-addon"><i class="glyphicon glyphicon-calendar fa fa-calendar"></i></span>
											<input type="date" name="to_calendar" id="to_calendar" class="form-control" placeholder="mm/dd/yyy" required="">
											</div>
										</div>
									</div>
									<div class="input-group">
	                                    <button class="btn btn-success btn-rounded" id="history_btn" style="display: block; margin: 0 auto;"><i class="fa fa-bullseye"></i> Search Records</button>
	                                 </div>
								</div>
							</div>
                        </form>
                        
					  </div>
                    </div>
                </div>

                <div class="row">             

                <div class="col-md-12">
                    <div class="card">
                        <div class="card-header card-default">
                            Search Results
                        </div>
                        <div class="table-rep-plugin">
                        	<div class="table-responsive" data-pattern="priority-columns">
                        		<!-- <h4 class="text-center">Search Results</h4> -->
                        		<div class="card-body">
                        			<table id="datatable" class="table table-striped">
                        				<thead>
                        					<tr>
                        						<th>ID</th>
					                            <th>Date/Time</th>
					                            <th>Amount</th>
				                            </tr>
				                        </thead>
				                        <tbody id="hist_tbl"></tbody>
				                    </table>
                                </div>
                            </div>
                                 <!-- end table-responsive-->
                        </div>
                              <!-- table-rep-plugin-->
                        
					  </div>
                    </div>
                </div>
                <input type="hidden" id="identifier" value="dh&amp;$page">
				
				
            <footer class="footer">
                <span>Copyright © 2019 BIT TRADE ASSETS</span>
            </footer>


        </section>
        <!-- ============================================================== -->
		<!-- 						Content End		 						-->
		<!-- ============================================================== -->



        <!-- Common Plugins -->
        <script src="assets/lib/jquery/dist/jquery.min.js"></script>
		<script src="assets/lib/bootstrap/js/popper.min.js"></script>
        <script src="assets/lib/bootstrap/js/bootstrap.min.js"></script>
        <script src="assets/lib/pace/pace.min.js"></script>
        <script src="assets/lib/jasny-bootstrap/js/jasny-bootstrap.min.js"></script>
        <script src="assets/lib/slimscroll/jquery.slimscroll.min.js"></script>
        <script src="assets/lib/nano-scroll/jquery.nanoscroller.min.js"></script>
        <script src="assets/lib/metisMenu/metisMenu.min.js"></script>
        <script src="assets/js/custom.js"></script>
        <script src="assets/js/control.js"></script>

        <!-- Datatables-->
        <script src="assets/lib/datatables/jquery.dataTables.min.js"></script>
        <script src="assets/lib/datatables/dataTables.responsive.min.js"></script>
        <script src="assets/lib/toast/jquery.toast.min.js"></script>
        <script src="assets/js/dashboard.js"></script>
		<script src="assets/js/crypto.custom.js"></script>
		<script src="assets/lib/datatables/dataTables.buttons.min.js"></script>
		<script src="assets/lib/datatables/jszip.min.js"></script>
		<script src="assets/lib/datatables/pdfmake.min.js"></script>
		<script src="assets/lib/datatables/vfs_fonts.js"></script>
		<script src="assets/lib/datatables/buttons.html5.min.js"></script>
		
		<!-- DataTimePicker -->
        <script type="text/javascript" src="assets/lib/bootstrap-daterangepicker/moment.js"></script>
		<script type="text/javascript" src="assets/lib/bootstrap-daterangepicker/daterangepicker.js"></script>
		
		<!-- Clock Picker -->
		<script type="text/javascript" src="assets/lib/clockpicker/bootstrap-clockpicker.min.js"></script>

    

<style>.tb_button {padding:1px;cursor:pointer;border-right: 1px solid #8b8b8b;border-left: 1px solid #FFF;border-bottom: 1px solid #fff;}.tb_button.hover {borer:2px outset #def; background-color: #f8f8f8 !important;}.ws_toolbar {z-index:100000} .ws_toolbar .ws_tb_btn {cursor:pointer;border:1px solid #555;padding:3px}   .tb_highlight{background-color:yellow} .tb_hide {visibility:hidden} .ws_toolbar img {padding:2px;margin:0px}</style></body></html>