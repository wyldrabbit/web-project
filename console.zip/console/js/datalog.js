$(document).ready(function(){
	//Registration Field
	$("#registration_form").submit(function(e){
		e.preventDefault();
		var email = $("#email").val();
		var password = $("#password").val();
		var confirm_password = $("#cpassword").val();
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
		if(password != confirm_password){
			toastr.error("Password Match!", "Your password does not match!");
			return false;
		}else if(!re.test(email)){   
		    toastr.error("Error!", "Wrong Email Format!");
			return false;
		}

			$("#reg_btn").text("Registering...");
			$("#reg_btn").attr("disabled", true);
			//Form Submission via Ajax
			$.ajax({
				url: "include/data-control.php",
				method: "post",
				data: $("#registration_form").serialize(),
				dataType: "text",
				success:function(status){
					var status = $.trim(status);
					if(status == 'found'){
							$("#reg_btn").text("Register");
							$("#reg_btn").attr("disabled", false);
						toastr.info("Email Found!", "Your email address has already been registered!");
					}
					else if(status == 'success'){
					$("#reg_btn").text("Registered");
						toastr.success("Registration Successful!", "Welcome to our platform. Please Wait!");
						setTimeout(function(){
							window.location="login";
						},4000);
					}
					else{
							$("#reg_btn").text("Register");
							$("#reg_btn").attr("disabled", false);
						toastr.error("Failed!", "Registration process was not successful!");
					}
				}
			});
	});
		//Login Field
	$("#login_form").submit(function(e){
		e.preventDefault();
		var login_email = $("#login_email").val();
		var login_password = $("#login_password").val();
			$("#um-submit-btn").text("Please Wait...");
			$("#um-submit-btn").attr("disabled", true);
			//Form Submission via Ajax
			$.ajax({
				url: "include/data-control.php",
				method: "post",
				data: 'login_email=' + login_email + '&login_password=' + login_password,
				dataType: "text",
				success:function(status){
					var status = $.trim(status);
					if(status == 'log_failed'){
					$("#um-submit-btn").text("Login");
					$("#um-submit-btn").attr("disabled", false);
						toastr.error("Login Failed!", "Email or Password is incorrect!");
					}
					else if(status == 'log_success'){
					$("#um-submit-btn").text("Login Successful");
							window.location.href="console";
					}
				}
			});
	});

	//contact Field
	$("#recover_form").submit(function(e){
		e.preventDefault();
		var recover_email = $("#recover_email").val();
		var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

		if(!re.test(recover_email)){   
		    toastr.error("Wrong Email Format!", "Wrong Email Format!");
			return false;
		}
			$("#recover_form button").text("Please Wait...");
			$("#recover_form button").attr("disabled", true);
			//Form Submission via Ajax
			$.ajax({
				url: "include/data-control.php",
				method: "post",
				data: $("#recover_form").serialize(),
				dataType: "text",
				success:function(status){
					status = $.trim(status);
					if(status == 'failed'){
					$("#recover_form button").text("Login");
					$("#recover_form button").attr("disabled", false);
						toastr.error("Reset Failed!", "Please try again later!");
					}
					else if(status == 'notfound'){
					$("#recover_form button").text("Send Token");
					$("#recover_form button").attr("disabled", false);
						toastr.error("Error!", "Email Address Not Found!");
					}
					else if(status == 'success'){
					$("#recover_form button").text("Send Token");
						toastr.success("Successful!", "New Password has been sent to your email address");
						setTimeout(function(){
						    window.location='login';
						},5000);
					}
				}
			});
	});
});