<?php  

require_once 'controllers/authController.php'; 

if (!isset($_SESSION['id'])) {
	header('Location: login.php');
	exit();
}

?>